@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sf-express.com/esb/service/BigFileService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sf.module.esbinterface.webservice.stub;
